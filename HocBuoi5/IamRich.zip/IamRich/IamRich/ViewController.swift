//
//  ViewController.swift
//  IamRich
//
//  Created by Toan-tech on 10/19/19.
//  Copyright © 2019 Toan-tech. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var rubyImageView: UIView!
    
    @IBOutlet weak var amRichLabel: UILabel!
    
    override func viewDidLoad() { //hàm viewDidLoad chỉ chạy 1 lần đầu tiên duy nhất
        super.viewDidLoad()
        
        rubyImageView.alpha = 0.0
        amRichLabel.alpha = 0.0
        
        
    }


}

